package src.com.BoulderDashTotal.Model.Gestionnary;

import java.util.ArrayList;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;
import src.com.BoulderDashTotal.Model.Objects.Entity.Player;


public abstract class BlockShifting {
	
	/**
	 * 
	 * Manage shifting for movable objects
	 * @author G�rald
	 * @param al				ArrayList of specified type
	 * @param mapTab			Array of object id for this map
	 * @param blockSize			Size of one block
	 * @param p					Player
	 * 
	 */
	
	public static void blockFall(ArrayList<Block> al, int mapTab[][], int blockSize, Player p) {
		for(Block b : al) {
				b.fall(mapTab, blockSize, p);
				b.fallDiagonallyRight(mapTab, blockSize, p);
				b.fallDiagonallyLeft(mapTab, blockSize, p);
			if(!b.getPushing() && b.getFalling() && b.getCounter() != blockSize) {
				b.setPy(b.getPy()+1);
				b.setCounter(b.getCounter()+1);
			}
			else {
				b.setFalling(false);
			}
		}
	}
	
	public static void BlockPushed(ArrayList<Block> al, int mapTab[][], int blockSize, Player p) {
		for(Block b : al) {
			if(!b.getPushing() && !b.getFalling()) {
				b.pushRight(mapTab, blockSize, p);
				b.pushLeft(mapTab, blockSize, p);
			}
			else if(b.getCounter() != blockSize && !b.getFalling())
				if(b.getPushToRight()) {
					b.setPx(b.getPx()+1);
					b.setCounter(b.getCounter()+1);
				}
				else {
					b.setPx(b.getPx()-1);
					b.setCounter(b.getCounter()+1);
				}
			else
				b.setPushing(false);
		}
	}
	
	public static void taken(ArrayList<Block> al, Player p) {
		for(int i = 0; i<al.size(); i++) {
			if(al.get(i).taken(p)) {
					al.remove(i);
					p.setDiamondCollected(p.getDiamondCollected() + 1);
			}
		}
	}
}
