package src.com.BoulderDashTotal.Model.Gestionnary;

import java.util.ArrayList;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block.Nothing;
import src.com.BoulderDashTotal.Model.Objects.Entity.Player;
import src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy.Enemy;


public abstract class EntityShifting {

	/**
	 * 
	 * Manage shifting for entity
	 * @author G�rald
	 * @param p 				Player
	 * @param blockSize			Size of one block
	 * @param mapTab			Array of object id for this map
	 * @param al				ArrayList of specified type
	 *
	 */
	
	public static void playerShifting(Player p, int blockSize, int mapTab[][], ArrayList<Block> al) {
		
		p.shifting(mapTab, blockSize);
		if(p.getMoving()) {
			if(p.getToUp()) {
				if(p.getCounter() < blockSize/2) {
					
					p.setSxInImg(0);
					p.setSyInImg(2);
					p.setPy(p.getPy()-1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize/2 && p.getCounter() < blockSize) {
					
					p.setSxInImg(1);
					p.setSyInImg(2);
					p.setPy(p.getPy()-1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() == blockSize) {
					
					p.setSxInImg(0);
					p.setSyInImg(0);
					p.setCounter(0);
					p.setMoving(false);
					p.setToUp(false);
					if(mapTab[p.getPx()/blockSize][p.getPy()/blockSize] != 1)
						al.add(new Nothing(p.getPx(), p.getPy()));
				}
			}
			if(p.getToDown()) {
				if(p.getCounter() < blockSize/2) {
					
					p.setSxInImg(0);
					p.setSyInImg(4);
					p.setPy(p.getPy()+1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize/2 && p.getCounter() < blockSize) {
					
					p.setSxInImg(1);
					p.setSyInImg(4);
					p.setPy(p.getPy()+1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() == blockSize) {
					
					p.setSxInImg(0);
					p.setSyInImg(0);
					p.setCounter(0);
					p.setMoving(false);
					p.setToDown(false);
					if(mapTab[p.getPx()/blockSize][p.getPy()/blockSize] != 1)
						al.add(new Nothing(p.getPx(), p.getPy()));
				}
			}
			if(p.getToLeft()) {
				if(p.getCounter() < blockSize/3) {
					
					p.setSxInImg(0);
					p.setSyInImg(1);
					p.setPx(p.getPx()-1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize/3 && p.getCounter() < blockSize*2/3) {
					
					p.setSxInImg(1);
					p.setSyInImg(1);
					p.setPx(p.getPx()-1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize*2/3 && p.getCounter() < blockSize) {
					
					p.setSxInImg(2);
					p.setSyInImg(1);
					p.setPx(p.getPx()-1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() == blockSize) {
					
					p.setSxInImg(0);
					p.setSyInImg(0);
					p.setCounter(0);
					p.setMoving(false);
					p.setToLeft(false);
					if(mapTab[p.getPx()/blockSize][p.getPy()/blockSize] != 1)
						al.add(new Nothing(p.getPx(), p.getPy()));
				}
			}
			if(p.getToRight()) {
				if(p.getCounter() < blockSize/3) {
					
					p.setSxInImg(0);
					p.setSyInImg(3);
					p.setPx(p.getPx()+1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize/3 && p.getCounter() < blockSize*2/3) {
					
					p.setSxInImg(1);
					p.setSyInImg(3);
					p.setPx(p.getPx()+1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() >= blockSize*2/3 && p.getCounter() < blockSize) {
					
					p.setSxInImg(2);
					p.setSyInImg(3);
					p.setPx(p.getPx()+1);
					p.setCounter(p.getCounter()+1);
				}
				if(p.getCounter() == blockSize) {
					
					p.setSxInImg(0);
					p.setSyInImg(0);
					p.setCounter(0);
					p.setMoving(false);
					p.setToRight(false);
					if(mapTab[p.getPx()/blockSize][p.getPy()/blockSize] != 1)
						al.add(new Nothing(p.getPx(), p.getPy()));
				}
			}
		}
	}
	
	public static void enemyShifting(ArrayList<Enemy> al, int mapTab[][], int blockSize) {
		for(Enemy e : al) {
			e.shifting(mapTab, blockSize);
			if(e.getMoving()) {
				if(e.getToUp() && e.getCounter() < blockSize) {
					mapTab[e.getPx()/blockSize][e.getPy()/blockSize] = 1;
					if(e.getSxInImg() == 9)
						mapTab[e.getPx()/blockSize][e.getPy()/blockSize-1] = 5;
					else
						mapTab[e.getPx()/blockSize][e.getPy()/blockSize-1] = 6;
					e.setCounter(e.getCounter()+1);
					e.setPy(e.getPy()-1);
				}
				else {
					e.setToUp(false);
					e.setMoving(false);
				}
				if(e.getToDown() && e.getCounter() < blockSize) {
					mapTab[e.getPx()/blockSize][e.getPy()/blockSize] = 1;
					if(e.getSxInImg() == 9)
						mapTab[e.getPx()/blockSize][e.getPy()/blockSize+1] = 5;
					else
						mapTab[e.getPx()/blockSize][e.getPy()/blockSize+1] = 6;
					e.setCounter(e.getCounter()+1);
					e.setPy(e.getPy()+1);
				}
				else {
					e.setToDown(false);
					e.setMoving(false);
				}
				if(e.getToLeft() && e.getCounter() < blockSize) {
					mapTab[e.getPx()/blockSize][e.getPy()/blockSize] = 1;
					if(e.getSxInImg() == 9)
						mapTab[e.getPx()/blockSize-1][e.getPy()/blockSize] = 5;
					else
						mapTab[e.getPx()/blockSize-1][e.getPy()/blockSize] = 6;
					e.setCounter(e.getCounter()+1);
					e.setPx(e.getPx()-1);
				}
				else {
					e.setToLeft(false);
					e.setMoving(false);
				}
				if(e.getToRight() && e.getCounter() < blockSize) {
					mapTab[e.getPx()/blockSize][e.getPy()/blockSize] = 1;
					if(e.getSxInImg() == 9)
						mapTab[e.getPx()/blockSize+1][e.getPy()/blockSize] = 5;
					else
						mapTab[e.getPx()/blockSize+1][e.getPy()/blockSize] = 6;
					e.setCounter(e.getCounter()+1);
					e.setPx(e.getPx()+1);
				}
				else {
					e.setToRight(false);
					e.setMoving(false);
				}
			}
		}
	}
}
