package src.com.BoulderDashTotal.Model.Gestionnary;

import src.com.BoulderDashTotal.Main.Game;


public class DisplayChrono implements Runnable {
	
	/**
	 * 
	 * Manage the uptdate of the screen
	 * @author G�rald
	 *
	 */
	
	private final int PAUSE = 3;
		
	public void run() {
			
		while(true) {
			
			Game.getGameWindow()
			.getGameDisplay()
			.repaint();
			try {
				Thread.sleep(PAUSE);
			} 
			catch (InterruptedException e) {}
		}
	}
}
