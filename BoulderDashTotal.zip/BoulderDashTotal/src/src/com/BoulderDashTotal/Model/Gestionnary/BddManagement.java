package src.com.BoulderDashTotal.Model.Gestionnary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Movable_Block.Diamond;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Movable_Block.Stone;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block.Brick;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block.Nothing;
import src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy.FirstEnemy;
import src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy.SecondEnemy;
import src.com.BoulderDashTotal.View.GameDisplay;

public class BddManagement {
	
	/**
	 * 
	 * Manage Database interaction with the software
	 * @author G�rald
	 * 
	 */
	
	Connection connector;
	
	public BddManagement() {
		
		this.connector = null;
		this.bddConnection();
	}
	
	public void bddConnection() {
		
		try {
			connector = DriverManager.getConnection("jdbc:mysql://localhost/javaproject", "root", "");
			System.out.println("Connection sucess");
		} catch(Exception e) {
			System.err.println(e);
		}
	}
	
	public void bddExecuteQueryGetMapObject(int mapId, GameDisplay gameDisplay) {
		ResultSet rs = null;
		String query = "CALL GetMapObject(" + mapId + ");";
		try {
			Statement stmt = connector.createStatement();
			rs = stmt.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		addResultSetToVariable(	gameDisplay, 
								rs);
	}
	
	public void bddExecuteQueryGetMapSize(int mapId, GameDisplay gameDisplay) {
		
		ResultSet rs = null;
		String query = "CALL GetMapSize(" + mapId + ");";
		try {
			Statement stmt = connector.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			gameDisplay.setXMapSize(rs.getInt("SIZE_X"));
			gameDisplay.setYMapSize(rs.getInt("SIZE_Y"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
		gameDisplay.setMapTab(new int[gameDisplay.getXMapSize()+2][gameDisplay.getYMapSize()+2]);
	}
	
	public void bddExecuteQueryGetMapDiamondNumber(int mapId, GameDisplay gameDisplay) {
		ResultSet rs = null;
		String query = "CALL GetMapDiamondNumber(" + mapId + ");";
		try {
			Statement stmt = connector.createStatement();
			rs = stmt.executeQuery(query);
			rs.next();
			gameDisplay.setNbrDiamonds(rs.getInt("NBR_DIAMONDS"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void addResultSetToVariable(GameDisplay gameDisplay, ResultSet rs) {
		
		try {
			while(rs.next()) {
				switch(rs.getString("OBJECT")) {
				case "Nothing":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 1;
					break;
				case "Brick":
					gameDisplay.getBlock().add(new Brick((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 2;
					break;
				case "Stone":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMovableBlock().add(new Stone((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 3;
					break;
				case "Diamond":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMovableBlock().add(new Diamond((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 4;
					break;
				case "FirstEnemy":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getEnemy().add(new FirstEnemy((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 5;
					break;
				case "SecondEnemy":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getEnemy().add(new SecondEnemy((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 6;
					break;
				case "Player":
					gameDisplay.getBlock().add(new Nothing((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize(), (rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize()));
					gameDisplay.getPlayer().setPx((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize());
					gameDisplay.getPlayer().setPy((rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize());
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 7;
					break;
				case "Exit":
					gameDisplay.getExit().setPx((rs.getInt("X_OBJECT")+1)*gameDisplay.getBlockSize()); 
					gameDisplay.getExit().setPy((rs.getInt("Y_OBJECT")+1)*gameDisplay.getBlockSize());
					gameDisplay.getMapTab()[rs.getInt("X_OBJECT")+1][rs.getInt("Y_OBJECT")+1] = 8;
					break;
				default:
		             throw new IllegalArgumentException("Invalid Object in Database");
				}
			}
		} catch (SQLException exception) {
			exception.printStackTrace();
		}
	}
}
