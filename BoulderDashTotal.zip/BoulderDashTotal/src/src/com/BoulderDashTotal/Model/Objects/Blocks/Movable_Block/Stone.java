package src.com.BoulderDashTotal.Model.Objects.Blocks.Movable_Block;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;


public class Stone extends Block {
	
	/**
	 * 
	 * Made of Stone
	 * @author G�rald
	 *
	 */
	
	public Stone(int px, int py) {
		
		super(px, py, 3, 0,  true, false);
	}
}
