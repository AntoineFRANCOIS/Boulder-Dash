package src.com.BoulderDashTotal.Model.Objects.Entity;

public class Player extends Entity {
	
	/**
	 * 
	 * Class Player
	 * @author G�rald
	 *
	 */
	
	private int diamondCollected;
	
	public Player(int px, int py) {
		
		super(px, py, "Player", 0, 0);
	}
	
	public void shifting(int mapTab[][], int blockSize) {
		
		this.whatsNext(mapTab, blockSize);
		if(!this.getMoving()) {
			if(	this.getToUp() && 
				(this.getUp() == 0 || 
				this.getUp() == 1 || 
				this.getUp() == 4 ||
				this.getUp() == 8)) {
				this.setMoving(true);
				this.setCounter(0);
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)-1] = 7;
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)] = 1;
			}
			else {
				this.setToUp(false);
			}
			if(	this.getToDown() && 
				(this.getDown() == 0 || 
				this.getDown() == 1 || 
				this.getDown() == 4 ||
				this.getDown() == 8)) {
				this.setMoving(true); 
				this.setCounter(0);
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)+1] = 7;
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)] = 1;
				}
			else {
				this.setToDown(false);
			}
			if(	this.getToLeft() && 
				(this.getLeft() == 0 || 
				this.getLeft() == 1 || 
				this.getLeft() == 4 ||
				this.getLeft() == 8)) {
				this.setMoving(true);
				this.setCounter(0);
				mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)] = 7;
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)] = 1;
			}
			else {
				this.setToLeft(false);
			}
			if(	this.getToRight() &&
				(this.getRight() == 0 || 
				this.getRight() == 1 || 
				this.getRight() == 4 ||
				this.getRight() == 8)) {
				this.setMoving(true);
				this.setCounter(0);
				mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)] = 7;
				mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)] = 1;
			}
			else {
				this.setToRight(false);
			}
		}
	}

	public int getDiamondCollected() {return diamondCollected;}
	public void setDiamondCollected(int diamondCollected) {this.diamondCollected = diamondCollected;}
}
