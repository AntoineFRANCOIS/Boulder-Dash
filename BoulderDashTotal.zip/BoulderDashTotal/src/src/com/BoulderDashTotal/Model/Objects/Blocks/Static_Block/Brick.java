package src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;

public class Brick extends Block {
	
	/**
	 * 
	 * Made of Brick
	 * @author G�rald
	 *
	 */
	
	public Brick(int px, int py) {
		
		super(px, py, 8, 3, false, false);
	}
}
