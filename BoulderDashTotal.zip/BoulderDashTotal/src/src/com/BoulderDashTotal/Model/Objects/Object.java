package src.com.BoulderDashTotal.Model.Objects;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Object {
	
	/**
	 * 
	 * Content common to Object
	 * @author G�rald
	 *
	 */
	
	private int px;
	private int py;
	private Image img;
	private int sx;
	private int sy;
	private int sxInImg;
	private int syInImg;
	private int counter;
	private int up, down, left, right;
	
	public Object(int px, int py, String name, int sxInImg, int syInImg) {
		
		this.px = px;
		this.py = py;
		name = "/image/" + name + ".png";
		ImageIcon ico = new ImageIcon(getClass().getResource(name));
		this.img = ico.getImage();
		this.sx = 16;
		this.sy = 16;
		this.sxInImg = sxInImg;
		this.syInImg = syInImg;
		this.counter = 0;
		this.up = 0;
		this.down = 0;
		this.left = 0;
		this.right = 0;
	}
	
	public void whatsNext(int mapTab[][], int blockSize) {
		
		this.up = mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)-1];
		this.down = mapTab[(this.getPx()/blockSize)][(this.getPy()/blockSize)+1];
		this.left = mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)];
		this.right = mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)];
	}
	
	public int getPx() {return px;}
	public void setPx(int px) {this.px = px;}

	public int getPy() {return py;}
	public void setPy(int py) {this.py = py;}

	public Image getImg() {return img;}
	public void setImg(Image img) {this.img = img;}

	public int getSx() {return sx;}
	public void setSx(int sx) {this.sx = sx;}

	public int getSy() {return sy;}
	public void setSy(int sy) {this.sy = sy;}

	public int getSxInImg() {return sxInImg;}
	public void setSxInImg(int sxInImg) {this.sxInImg = sxInImg;}

	public int getSyInImg() {return syInImg;}
	public void setSyInImg(int syInImg) {this.syInImg = syInImg;}
	
	public int getCounter() {return counter;}
	public void setCounter(int counter) {this.counter = counter;}
	
	public int getUp() {return up;}
	public int getDown() {return down;}
	public int getLeft() {return left;}
	public int getRight() {return right;}
}
