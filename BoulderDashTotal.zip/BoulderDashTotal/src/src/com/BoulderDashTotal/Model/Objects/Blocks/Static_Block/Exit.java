package src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;

public class Exit extends Block {
	
	/**
	 * 
	 * Made of Exit
	 * @author G�rald
	 *
	 */
	
	public Exit(int px, int py) {
		
		super(px, py, 6, 2, false, false);
	}
}
