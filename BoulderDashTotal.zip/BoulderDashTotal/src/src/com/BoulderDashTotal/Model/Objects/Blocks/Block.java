package src.com.BoulderDashTotal.Model.Objects.Blocks;

import src.com.BoulderDashTotal.Model.Objects.Object;
import src.com.BoulderDashTotal.Model.Objects.Entity.Player;

public abstract class Block extends Object {
	
	/**
	 * 
	 * Content common to Block
	 * @author G�rald
	 *
	 */
	
	private boolean traversable;
	private boolean canFall;
	private boolean falling;
	private boolean pushing;
	private boolean pushToRight;
	
	public Block(int px, int py, int sxInImg, int syInImg,  boolean canFall, boolean traversable) {
		
		super(px, py, "Bloc", sxInImg, syInImg);
		this.canFall = canFall;
		this.traversable = traversable;
	}
	
	public void fall(int mapTab[][], int blockSize, Player p) {
		this.whatsNext(mapTab, blockSize);
		if(this.getDown() == 1 && this.getCanFall() && !this.getFalling() && !this.getPushing()) {
			
			mapTab[this.getPx()/blockSize][this.getPy()/blockSize] = 1;
			if(this.isTraversable())
				mapTab[this.getPx()/blockSize][(this.getPy()/blockSize)+1] = 4;
			else
				mapTab[this.getPx()/blockSize][(this.getPy()/blockSize)+1] = 3;
			this.setFalling(true);
			this.setCounter(0);
		}
		if(this.getDown() == 7 && this.getFalling() && this.getPx() == p.getPx()) {
			p.setAlive(false);
			this.setFalling(false);
		}
	}
	
	public void fallDiagonallyRight(int mapTab[][], int blockSize, Player p) {
		this.whatsNext(mapTab, blockSize);
		if((this.getDown() == 3 || this.getDown() == 4) && this.getRight() == 1 && mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)+1] == 1 
			&& this.getCanFall() && !this.getFalling()) {
			mapTab[this.getPx()/blockSize][this.getPy()/blockSize] = 1;
			if(this.isTraversable())
				mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)] = 4;
			else
				mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)] = 3;
			this.setPx(this.getPx()+blockSize);
			this.fall(mapTab, blockSize, p);
		}
		if((this.getDown() == 3 || this.getDown() == 4) && this.getRight() == 1 && mapTab[(this.getPx()/blockSize)+1][(this.getPy()/blockSize)+1] == 7 
				&& this.getCanFall() && this.getFalling() && this.getPx() == p.getPx()) {
				p.setAlive(false);
		}
	}
	
	public void fallDiagonallyLeft(int mapTab[][], int blockSize, Player p) {
		this.whatsNext(mapTab, blockSize);
		if((this.getDown() == 3 || this.getDown() == 4) && this.getLeft() == 1 && mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)+1] == 1 
				&& this.getCanFall() && !this.getFalling()) {
				mapTab[this.getPx()/blockSize][this.getPy()/blockSize] = 1;
				if(this.isTraversable())
					mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)] = 4;
				else
					mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)] = 3;
				this.setPx(this.getPx()-blockSize);
				this.fall(mapTab, blockSize, p);
			}
			if((this.getDown() == 3 || this.getDown() == 4) && this.getLeft() == 1 && mapTab[(this.getPx()/blockSize)-1][(this.getPy()/blockSize)+1] == 7 
					&& this.getCanFall() && this.getFalling() && this.getPx() == p.getPx()) {
					p.setAlive(false);
			}
	}
	
	public void pushRight(int mapTab[][], int blockSize, Player p) {
		this.whatsNext(mapTab, blockSize);
		if(this.getLeft() == 7 && this.getRight() == 1 && p.getToRight() && !this.isTraversable() && !getPushing() && p.getPx() == this.getPx()-blockSize) {
			mapTab[this.getPx()/blockSize][this.getPy()/blockSize] = 1;
			mapTab[this.getPx()/blockSize+1][this.getPy()/blockSize] = 3;
			this.setPushing(true);
			this.setCounter(0);
			this.setPushToRight(true);
		}
	}
	
	public void pushLeft(int mapTab[][], int blockSize, Player p) {
		this.whatsNext(mapTab, blockSize);
		if(this.getLeft() == 1 && this.getRight() == 7 && p.getToLeft() && !this.isTraversable() && !getPushing() && p.getPx() == this.getPx()+blockSize) {
			mapTab[this.getPx()/blockSize][this.getPy()/blockSize] = 1;
			mapTab[this.getPx()/blockSize-1][this.getPy()/blockSize] = 3;
			this.setPushing(true);
			this.setCounter(0);
			this.setPushToRight(false);
		}
	}
	
	public boolean taken(Player p) {
		if(this.getPx() == p.getPx() && this.getPy() == p.getPy()) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void setFalling(boolean falling) {this.falling = falling;}
	public boolean getFalling() {return this.falling;}
	
	public void setPushing(boolean pushing) {this.pushing = pushing;}
	public boolean getPushing() {return this.pushing;}
	
	public void setPushToRight(boolean pushToRight) {this.pushToRight = pushToRight;}
	public boolean getPushToRight() {return this.pushToRight;}
	
	public void setCanFall(boolean canFall) {this.canFall = canFall;}
	public boolean getCanFall() {return this.canFall;}

	public boolean isTraversable() {return traversable;}
	public void setTraversable(boolean traversable) {this.traversable = traversable;}
}
