package src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;

public class Nothing extends Block {
	
	/**
	 * 
	 * Made of Nothing
	 * @author G�rald
	 *
	 */
	
	public Nothing(int px, int py) {
		
		super(px, py, 2, 0, false, true);
	}
}
