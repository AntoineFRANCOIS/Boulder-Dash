package src.com.BoulderDashTotal.Model.Objects.Entity;

import src.com.BoulderDashTotal.Model.Objects.Object;

public abstract class Entity extends Object {
	
	/**
	 * 
	 * Content common to Entity
	 * @author G�rald
	 *
	 */
	
	private Boolean moving;
	private Boolean toUp;
	private Boolean toDown;
	private Boolean toLeft;
	private Boolean toRight;
	private Boolean alive;
	
	public Entity(int px, int py, String name, int sxInImg, int syInImg) {
		
		super(px, py, name, sxInImg, syInImg);
		this.moving = false;
		this.toUp = false;
		this.toDown = false;
		this.toLeft = false;
		this.toRight = false;
		this.alive = true;
	}
	
	public void deplacement() {}
	
	public void explosion(boolean diamond) {
		
	}
	
	public Boolean getMoving() {return moving;}
	public void setMoving(Boolean moving) {this.moving = moving;}
	
	public Boolean getToUp() {return toUp;}
	public void setToUp(Boolean toUp) {this.toUp = toUp;}

	public Boolean getToDown() {return toDown;}
	public void setToDown(Boolean toDown) {this.toDown = toDown;}

	public Boolean getToLeft() {return toLeft;}
	public void setToLeft(Boolean toLeft) {this.toLeft = toLeft;}

	public Boolean getToRight() {return toRight;}
	public void setToRight(Boolean toRight) {this.toRight = toRight;}
	
	public Boolean getAlive() {return alive;}
	public void setAlive(Boolean alive) {this.alive = alive;}
	
	public Boolean getIsMoving() {
		if(this.getToUp() || this.getToDown() || this.getToLeft() || this.getToRight() || this.getMoving()) { return true; }
		else { return false; }
	}
}
