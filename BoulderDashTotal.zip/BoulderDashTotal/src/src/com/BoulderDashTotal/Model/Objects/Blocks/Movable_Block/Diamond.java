package src.com.BoulderDashTotal.Model.Objects.Blocks.Movable_Block;

import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;


public class Diamond extends Block {

	/**
	 * 
	 * Made of Diamond
	 * @author G�rald
	 *
	 */
	
	public Diamond(int px, int py) {
		
		super(px, py, 4, 0, true, true);
	}
}
