package src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy;

public class SecondEnemy extends Enemy{
	
	/**
	 * 
	 * Made an enemy
	 * @author G�rald
	 *
	 */
	
	public SecondEnemy(int px, int py) {
		
		super(px, py, 10, 0);
	}
}
