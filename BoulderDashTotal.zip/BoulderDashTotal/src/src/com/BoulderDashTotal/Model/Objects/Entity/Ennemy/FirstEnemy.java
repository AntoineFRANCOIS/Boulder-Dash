package src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy;

public class FirstEnemy extends Enemy {
	
	/**
	 * 
	 * Made an enemy
	 * @author G�rald
	 *
	 */
	
	public FirstEnemy(int px, int py) {
		
		super(px, py, 9, 0);
	}
}
