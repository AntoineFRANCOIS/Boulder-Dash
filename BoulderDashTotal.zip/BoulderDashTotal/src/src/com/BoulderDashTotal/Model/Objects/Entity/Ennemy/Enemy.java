package src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy;

import src.com.BoulderDashTotal.Model.Objects.Entity.Entity;

public class Enemy extends Entity {

	/**
	 * 
	 * @author G�rald
	 *
	 */
	
	private char lastMove;
	private int antiLoop;
	
	public Enemy(int px, int py, int sxInImg, int syInImg) {
		
		super(px, py, "Bloc", sxInImg, syInImg);
		this.lastMove = 'u';
	}

	public void shifting(int mapTab[][], int blockSize) {
		
		if(!this.getMoving()) {
			this.whatsNext(mapTab, blockSize);	
			this.antiLoop = 0;
			if(this.lastMove == 'u')
				leftVerification(mapTab, blockSize);
			if(this.lastMove == 'd')
				rightVerification(mapTab, blockSize);
			if(this.lastMove == 'l')
				downVerification(mapTab, blockSize);
			if(this.lastMove == 'r')
				upVerification(mapTab, blockSize);
		}
	}
	
	private void upVerification(int mapTab[][], int blockSize) {
		this.whatsNext(mapTab, blockSize);
		if(this.antiLoop != 3)
			if(this.getUp() == 1) {
				this.lastMove = 'u';
				this.setCounter(0);
				this.setToUp(true);
				this.setMoving(true);
			}
			else {
				this.antiLoop++;
				this.rightVerification(mapTab, blockSize);
			}
	}
	
	private void rightVerification(int mapTab[][], int blockSize) {
		this.whatsNext(mapTab, blockSize);
		if(this.antiLoop != 3)
			if(this.getRight() == 1) {
				this.lastMove = 'r';
				this.setCounter(0);
				this.setToRight(true);
				this.setMoving(true);
			}
			else {
				this.antiLoop++;
				downVerification(mapTab, blockSize);
			}
	}
	
	private void downVerification(int mapTab[][], int blockSize) {
		this.whatsNext(mapTab, blockSize);
		if(this.antiLoop != 3)
			if(this.getDown() == 1) {
				this.lastMove = 'd';
				this.setCounter(0);
				this.setToDown(true);
				this.setMoving(true);
			}
			else {
				this.antiLoop++;
				leftVerification(mapTab, blockSize);
			}
	}
	
	private void leftVerification(int mapTab[][], int blockSize) {
		this.whatsNext(mapTab, blockSize);
		if(this.antiLoop != 3)
			if(this.getLeft() == 1) {
				this.lastMove = 'l';
				this.setCounter(0);
				this.setToLeft(true);
				this.setMoving(true);
			}
			else {
				this.antiLoop++;
				upVerification(mapTab, blockSize);
			}
	}
	
	public char getLastMove() {return lastMove;}
	public void setLastMove(char lastMove) {this.lastMove = lastMove;}
}
