package src.com.BoulderDashTotal.Controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import src.com.BoulderDashTotal.Main.Game;

public class Keyboard implements KeyListener {

	/**
	 * 
	 * Manage interaction between human player and the software
	 * @author G�rald
	 * @param e				Key pressed
	 *
	 */
	
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_UP && !Game.getGameWindow().getGameDisplay().getPlayer().getIsMoving()) {
			Game.getGameWindow().getGameDisplay().getPlayer().setToUp(true);
		}
		if(e.getKeyCode() == KeyEvent.VK_DOWN && !Game.getGameWindow().getGameDisplay().getPlayer().getIsMoving()) {
			Game.getGameWindow().getGameDisplay().getPlayer().setToDown(true);
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT && !Game.getGameWindow().getGameDisplay().getPlayer().getIsMoving()) {
			Game.getGameWindow().getGameDisplay().getPlayer().setToLeft(true);
		}
		if(e.getKeyCode() == KeyEvent.VK_RIGHT && !Game.getGameWindow().getGameDisplay().getPlayer().getIsMoving()) {
			Game.getGameWindow().getGameDisplay().getPlayer().setToRight(true);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void keyTyped(KeyEvent e) {}
}
