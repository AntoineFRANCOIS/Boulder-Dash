package src.com.BoulderDashTotal.View;

import javax.swing.JFrame;

import src.com.BoulderDashTotal.Controller.Keyboard;
import src.com.BoulderDashTotal.Model.Gestionnary.BddManagement;

@SuppressWarnings("serial")
public class GameWindow extends JFrame {
	
	/**
	 * 
	 * Window manager
	 * @author G�rald
	 *
	 */
	
	private int mapId;
	private GameDisplay gameDisplay;
	private BddManagement bddManagement;
	
	public GameWindow(int mapId) {
		
		this.mapId = mapId;
		bddManagement = new BddManagement();
		gameDisplay = new GameDisplay();
		bddManagement.bddExecuteQueryGetMapSize(this.mapId, this.gameDisplay);
		bddManagement.bddExecuteQueryGetMapObject(this.mapId, this.gameDisplay);
		bddManagement.bddExecuteQueryGetMapDiamondNumber(this.mapId, this.gameDisplay);
		this.intializeWindow();
	}
	
	private void intializeWindow() {
		this.setResizable(false);
		this.setAlwaysOnTop(false);
		this.setVisible(true);
		
		this.setContentPane(gameDisplay);
		this.setTitle("BoulderDash");
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(	(gameDisplay.getXMapSize()+2)*gameDisplay.getBlockSize(), 
						(gameDisplay.getYMapSize()+2)*gameDisplay.getBlockSize(), 
						gameDisplay.getBlockSize()*(gameDisplay.getXMapSize()+2)+6, 
						gameDisplay.getBlockSize()*(gameDisplay.getYMapSize()+2)+35);
		
		this.setFocusable(true);
		this.requestFocusInWindow();
		this.addKeyListener(new Keyboard());
	}

	public int getMapId() {return mapId;}
	public void setMapId(int mapId) {this.mapId = mapId;}

	public GameDisplay getGameDisplay() {return gameDisplay;}
	public void setGameDisplay(GameDisplay gameDisplay) {this.gameDisplay = gameDisplay;}

	public BddManagement getBddManagement() {return bddManagement;}
	public void setBddManagement(BddManagement bddManagement) {this.bddManagement = bddManagement;}
}
