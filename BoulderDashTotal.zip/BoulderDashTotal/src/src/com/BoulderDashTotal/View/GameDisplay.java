package src.com.BoulderDashTotal.View;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import src.com.BoulderDashTotal.Model.Gestionnary.BlockShifting;
import src.com.BoulderDashTotal.Model.Gestionnary.DisplayChrono;
import src.com.BoulderDashTotal.Model.Gestionnary.EntityShifting;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Block;
import src.com.BoulderDashTotal.Model.Objects.Blocks.Static_Block.Exit;
import src.com.BoulderDashTotal.Model.Objects.Entity.Player;
import src.com.BoulderDashTotal.Model.Objects.Entity.Ennemy.Enemy;

@SuppressWarnings("serial")
public class GameDisplay extends JPanel {
	
	/**
	 * 
	 * Display manager
	 * @author G�rald
	 *
	 */
	
	private ArrayList<Block> block; 
	private ArrayList<Block> movableBlock; 
	private ArrayList<Enemy> enemy; 
	private Player player; 
	private Exit exit;
	private Image wallImg;
	private int[][] mapTab; 
	private int nbrDiamonds;
	private int blockSize;
	private int xMapSize;
	private int yMapSize;
	private boolean speedReducer;
	private Font police;
	
	public Thread displayChrono;
	
	public GameDisplay() {
		
		this.blockSize = 32;
		ImageIcon ico = new ImageIcon(getClass().getResource("/image/Bloc.png"));
		this.wallImg = ico.getImage();
		this.block = new ArrayList<Block>();
		this.movableBlock = new ArrayList<Block>();
		this.enemy = new ArrayList<Enemy>();
		this.player = new Player(0, 0);
		this.exit = new Exit(0, 0);
		
		this.police = new Font("Arial", Font.PLAIN, blockSize);
		
		this.displayChrono = new Thread(new DisplayChrono());
	}
	
	private void paintBackground(Graphics g) {
		
		for(int i = 0; i<xMapSize+2; i++)
			for(int j = 0; j<yMapSize+2; j++)
				if(j == 0 || j == yMapSize+1 || i == 0 || i == xMapSize+1) {
					paintOneWall(g, i, j);
					mapTab[i][j] = 9;
				}
				else {
					paintOneDirt(g, i, j);
				}			
	}
	
	private void paintOneWall(Graphics g, int i, int j) {
		
		g.drawImage(this.wallImg, 
					i*this.blockSize, 
					j*this.blockSize, 
					i*this.blockSize+blockSize, 
					j*this.blockSize+blockSize, 
					0, 
					0, 
					16, 
					16, 
					null);
	}
	
	private void paintOneDirt(Graphics g, int i, int j) {
		
		g.drawImage(this.wallImg, 
					i*this.blockSize, 
					j*this.blockSize, 
					i*this.blockSize+blockSize, 
					j*this.blockSize+blockSize, 
					16, 
					0, 
					32, 
					16, 
					null);
	}	
	
	private void paintBlock(Graphics g) {
		
		for(Iterator<Block> it= block.iterator(); it.hasNext();) {
			Block b = it.next();
			g.drawImage(b.getImg(),
						b.getPx(),
						b.getPy(),
						b.getPx()+blockSize, 
						b.getPy()+blockSize, 
						b.getSxInImg()*b.getSx(), 
						b.getSyInImg()*b.getSy(),
						(b.getSxInImg()+1)*b.getSx(), 
						(b.getSyInImg()+1)*b.getSy(),
						null);
		}
	}
	
	private void paintMovableBlock(Graphics g) {
		
		for(Iterator<Block> it= movableBlock.iterator(); it.hasNext();) {
			Block b = it.next();
			g.drawImage(b.getImg(),
						b.getPx(),
						b.getPy(),
						b.getPx()+blockSize, 
						b.getPy()+blockSize, 
						b.getSxInImg()*b.getSx(), 
						b.getSyInImg()*b.getSy(),
						(b.getSxInImg()+1)*b.getSx(), 
						(b.getSyInImg()+1)*b.getSy(),
						null);
		}
	}
	
	private void paintEnemy(Graphics g) {
		
		for(Iterator<Enemy> it= enemy.iterator(); it.hasNext();) {
			Enemy e = it.next();
			g.drawImage(e.getImg(),
						e.getPx(),
						e.getPy(),
						e.getPx()+blockSize, 
						e.getPy()+blockSize, 
						e.getSxInImg()*e.getSx(), 
						e.getSyInImg()*e.getSy(),
						(e.getSxInImg()+1)*e.getSx(), 
						(e.getSyInImg()+1)*e.getSy(),
						null);
		}
	}
	
	private void paintPlayer(Graphics g) {
		
		g.drawImage(player.getImg(),
					player.getPx(),
					player.getPy(),
					player.getPx()+blockSize, 
					player.getPy()+blockSize, 
					player.getSxInImg()*player.getSx(), 
					player.getSyInImg()*player.getSy(),
					(player.getSxInImg()+1)*player.getSx(), 
					(player.getSyInImg()+1)*player.getSy(),
					null);
	}
	
	private void paintExit(Graphics g) {
		
		g.drawImage(exit.getImg(),
				exit.getPx(),
				exit.getPy(),
				exit.getPx()+blockSize, 
				exit.getPy()+blockSize, 
				exit.getSxInImg()*exit.getSx(), 
				exit.getSyInImg()*exit.getSy(),
				(exit.getSxInImg()+1)*exit.getSx(), 
				(exit.getSyInImg()+1)*exit.getSy(),
				null);
	}
	
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		g.setColor(Color.BLACK);
		g.setFont(police);
		
		paintBackground(g);
		paintBlock(g);
		paintMovableBlock(g);
		paintEnemy(g);
		g.drawString(this.player.getDiamondCollected() + " / " + this.getNbrDiamonds() + " Diamonds Collected.", blockSize, blockSize-5);
		
		BlockShifting.BlockPushed(movableBlock, mapTab, blockSize, player);
		if(player.getAlive()) {
			EntityShifting.playerShifting(player, blockSize, mapTab, block);
			if(speedReducer) {
				BlockShifting.blockFall(movableBlock, mapTab, blockSize, player);
				EntityShifting.enemyShifting(enemy, mapTab, blockSize);
				BlockShifting.taken(movableBlock, player);
				speedReducer = false;
			}
			else {
				speedReducer = true;
			}
			if(this.player.getDiamondCollected() >= this.getNbrDiamonds()) {
				exit.setSxInImg(6);
				exit.setSyInImg(0);
				paintExit(g);
				if(player.getPx() == exit.getPx() && player.getPy() == exit.getPy())
					System.exit(1);
			}
			else {
				paintExit(g);
			}
		}
		else {
			System.exit(1);
		}
		
		paintPlayer(g);
	}

	public ArrayList<Block> getBlock() {return block;}
	public void setBlock(ArrayList<Block> block) {this.block = block;}

	public ArrayList<Block> getMovableBlock() {return movableBlock;}
	public void setMovableBlock(ArrayList<Block> movableBlock) {this.movableBlock = movableBlock;}

	public ArrayList<Enemy> getEnemy() {return enemy;}
	public void setEnemy(ArrayList<Enemy> enemy) {this.enemy = enemy;}

	public int[][] getMapTab() {return mapTab;}
	public void setMapTab(int[][] mapTab) {this.mapTab = mapTab;}

	public Player getPlayer() {return player;}
	public void setPlayer(Player player) {this.player = player;}

	public int getBlockSize() {return blockSize;}
	public void setBlockSize(int blockSize) {this.blockSize = blockSize;}
	
	public int getXMapSize() {return xMapSize;}
	public void setXMapSize(int xMapSize) {this.xMapSize = xMapSize;}

	public int getYMapSize() {return yMapSize;}
	public void setYMapSize(int yMapSize) {this.yMapSize = yMapSize;}

	public int getNbrDiamonds() {return nbrDiamonds;}
	public void setNbrDiamonds(int nbrDiamonds) {this.nbrDiamonds = nbrDiamonds;	}

	public Exit getExit() {return exit;}
	public void setExit(Exit exit) {this.exit = exit;}
}
