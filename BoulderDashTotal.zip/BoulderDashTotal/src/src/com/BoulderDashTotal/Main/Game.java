package src.com.BoulderDashTotal.Main;

import src.com.BoulderDashTotal.View.GameWindow;

public class Game {

	/**
	 * 
	 * Main of the Game
	 * @author G�rald
	 *
	 */

	
	private static GameWindow gameWindow;
	
	public static void main(String[] args) {
		
		setGameWindow(new GameWindow(1));
		gameWindow.getGameDisplay().displayChrono.start();
	}

	public static GameWindow getGameWindow() {return gameWindow;}
	public static void setGameWindow(GameWindow gameWindow) {Game.gameWindow = gameWindow;}
}
